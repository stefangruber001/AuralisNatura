# Handoff: Auralis Natura — Dokumentenbibliothek v2

## Overview
Complete redesign (v2) of every document the Auralis Natura Betriebskonsole produces: 11 e-mails, the 12-page A4 client report (DE/EN/ES), 13 Instagram templates, the GDPR data-export view, 5 operations manuals and the LIESMICH index. Task for Claude Code: **replace the old v1 templates in the codebase with these v2 versions** and parameterize them so every future customer gets identical output.

## About the Design Files
The files in `Auralis-Dokumente_v2/` are **production-grade HTML references** filled with one sample customer (Elena Martín, program "Wandel", booking BK-MUSTER, AN-0042). They are self-contained (system fonts fallback + self-hosted woff2, no CDN, no JS) and render pixel-identically in Chrome — the console's existing pipeline (Jinja-style string templates → Gmail draft / headless-Chrome PDF / PNG) can adopt them directly. The work is: lift each file into the corresponding renderer, replace the sample values with template variables (list below), and delete the v1 templates.

## Fidelity
**High-fidelity.** Colors, typography, spacing, chart geometry and print behavior are final. Do not restyle; only parameterize.

## File → Renderer Mapping (replace v1 in place)
| v2 file | Replaces output of |
|---|---|
| 01-Kundinnen-E-Mails/01…09 | `mailer.build_ack_email`, `build_booking_email`, `build_reminder_email`, `build_session_cancel_email`, `build_credentials_email`, `build_sessions_email`, `build_email` (report delivery), `build_feedback_email`, `build_newsletter` |
| 02-Interne-E-Mails/10, 11 | `mailer.build_internal_booking_email`, `mailer.build_social_package_email` |
| 03-Kundinnen-Bericht/Bericht-{de,en,es}.html | `render.build_html` + `render.to_pdf` (the 12-page PDF) |
| 05-Social-Media/*.html | `socialrender.tpl_*` (render to PNG/JPEG at 1080×1350 or 1080×1920, deviceScaleFactor 1, then JPEG-convert for Instagram) |
| 06-Datenauskunft-DSGVO/Datenauskunft-Ansicht.html | `app.gdpr_export` (styled view; JSON stays as-is) |
| 07-Anleitungen-und-Handbuecher/*.html | static handover docs (print from browser) |
| 00-LIESMICH.html | library index (docs only) |

## ⚠ Preview envelope in e-mails
Every e-mail starts with `<div class="env">…</div>` (Betreff/An/Cc strip). **This is review chrome only — strip it before sending.** Everything from `<main class="card">` down is the actual e-mail body.

## Design System (binding)
- Fonts: **Fraunces** (display, weight 340–420) + **Hanken Grotesk** (body), self-hosted in `_assets/fonts/` — keep self-hosted (GDPR).
- Tokens: `--ink #281F16`, `--ink-soft #5C4A3A`, `--ink-faint #75685A`, `--forest #3D2719`, `--forest-deep #221305`, `--sage #927B4A`, `--sage-soft #DAC79E`, `--clay #A8492A` (action color only), `--clay-deep #8F3D22`, `--gold #AD7A32`, `--gold-bright #D6A84E`, `--paper #F5EEE0`, `--paper-2 #ECE2CE`, `--cream #FBF6EB`, plus derived **pine green** `--pine #3A4A2C / --pine-soft #54663E / --pine-deep #1C2513` (report only, marks *positive* things).
- Rules: **square corners everywhere** (no border-radius), hairline borders `rgba(61,39,25,.14)`, wide soft shadows, no hyphenation, German master copy.
- Assets in `_assets/`: `emblem-320.png`, `emblem-96.png` (botanical seal), `wordmark.png`, `qr-portal.png`.

## v2 Upgrades that must survive parameterization
**Contrast system (all docs):** dark forest gradient bands `linear-gradient(168deg,#5A3A22,#3D2719 55%,#221305)` for e-mail mastheads, manual heroes, TOC cards, table headers (`.tbl th`, gantt/tracker headers — gold-bright type on forest); tonal `--paper` strips on card captions/footers; step numerals filled forest with cream text; gold top-hairline on cards.

**E-mails:** appointment "ticket" with dark date tile (cancelled state: `.ticket.off` = muted tile + strike + red stamp), calendar-row (Google/Outlook/Apple), timeline with gold diamond rail (E-Mail 06), credentials card (E-Mail 05), self-rating scales in internal briefing (clay when value ≤2 on 1–5 scale), Art.-9-DSGVO warning box (internal only).

**Report v2.1 (the flagship — 12 pages/language):**
1. Cover (framed, no footer on cover — footer collided with frame).
2. Letter + brand medal (emblem in gold ring), Spark ornament (clay/gold/pine diamonds), legend Stärke=pine / Hebel=gold / Priorität=clay.
3. TOC (5 chapters — the former dark "Wann zur Ärztin" page was **removed**; its content now lives as clay `.medbox` "Wann zum Arzt oder zur Ärztin" (gender-neutral) at the end of chapter 05).
4. "Auf einen Blick" dashboard: color-legend strip, **6-axis radar** (values colored: ≥4 pine, 3 sage, ≤2 clay), 6 self-rating gauges, **energy day-curve** (SVG, annotated morning window pine / 15-h dip clay), **lever bars** (Schlafrhythmus 40 / Ernährung 25 / Stressbalance 20 / Bewegung 15 %), 3 priorities with pine "Erster Schritt" lines.
5. Chapters each carry a visual: ch01 gauges, ch02 day-curve, ch03 three cofactor stat tiles, ch04 **granular Gantt** (6 action rows with one-line definitions, clay/gold/pine bars, soft=maintain, gold diamonds = milestones W2 Kurz-Check / W4 Review-Gespräch, legend row), ch05 14-day timeline + medbox.
6. Page 10 weekly plan + **Maßnahmen-Glossar** (every action defined in plain language — keep: users must always find what e.g. "Schlaffenster 23–7" means).
7. Page 11: 28-day tracker (pine checkboxes, dark week headers). Page 12: dark closing with QR.
8. **Footer every page (except cover):** `Auralis Natura · <report title> | <client name> · Programm „<program>“ | Seite NN` — map to `{client_name}`, `{package_name}`.
9. **Print hardening:** `@page{size:A4;margin:0}`, `print-color-adjust:exact`, print page height **296.6mm** (prevents blank-page spill), `.page:last-child{page-break-after:auto}`, one `<section class="page">` per sheet, `overflow:hidden`.

## Content budgets (critical for next customers)
Pages are fixed 297mm boxes — agent-generated text must respect these or it clips:
- Chapter pages: intro lead ≤ ~340 chars, second paragraph ≤ ~300 chars, 2–3 steps with ≤ ~90-char sublines.
- Glance page: priorities title ≤ 30 chars, description ≤ 60, first step ≤ 45.
- Gantt: exactly 6 rows + milestone row; row label ≤ 28 chars, definition ≤ 60.
- Glossary: 5 terms, definitions ≤ 220 chars.
- Radar/gauges: exactly 6 metrics, values 1–5; keep the color rule (≥4 pine, 3 sage, ≤2 clay).
Validate rendered pages with the fit-check used during design: for each `.page`, `pin.scrollHeight ≤ pin.clientHeight` and no element bottom below `.pfoot` top.

## Personalization variables
`{client_name}`, `{client_email}`, `{language de|en|es}`, `{package_name}` + price, `{booking_id}`, `{an_number}`, dates/times + `Europe/Madrid`, portal URL + one-click token, login credentials (mail 05), session list (mail 06), report: `{vals[6]}`, `{themes[]}`, `{prios[3]}`, `{curve_points[]}`, `{lever_weights[]}`, `{gantt_rows[]}`, `{milestones[]}`, `{defs[]}`, page-count reference in mail 07 ("12 Seiten") — compute, don't hardcode.

## Language rule
DE is master; EN/ES frames (headings, captions, legends, footers) are fully localized in the three report files — chapter body text is sample data and is generated per customer in the customer's language by the agent.

## Legal guardrails (already embedded — keep verbatim)
Coaching-not-medicine disclaimer, "Dr. rer. nat." disclosure, 112 emergency note, GDPR Art. 9 handling, no invented testimonials.

## Files
Everything under `Auralis-Dokumente_v2/` in this bundle; shared assets in `Auralis-Dokumente_v2/_assets/`.

## Screenshots
`screenshots/` holds reference captures: report (cover, letter, glance dashboard, gantt chapter, weekly plan + glossary, closing), flagship e-mail 02, internal briefing 10, manual hero, social carousel cover. The HTML files are the source of truth — screenshots are orientation only (step numerals may render slightly off in captures).
