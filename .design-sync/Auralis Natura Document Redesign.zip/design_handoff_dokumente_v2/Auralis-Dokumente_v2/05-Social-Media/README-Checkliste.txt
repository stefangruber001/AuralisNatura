AURALIS NATURA — WOCHENPAKET 2026-W35
=====================================

So kommen die Posts zu Instagram (Meta Business Suite, kostenlos):

1. business.facebook.com öffnen → „Planer" (Kalender-Symbol).
2. „Beitrag erstellen" → Instagram-Konto wählen.
3. Bild(er) aus diesem Paket hochladen (bei Karussells alle Slides in Reihenfolge).
4. Caption aus captions.txt des Slots einfügen (DE/EN/ES + Hashtags sind fertig gestapelt).
5. Barrierefreiheit → Alt-Text aus captions.txt setzen.
6. „Planen" → Tag und Uhrzeit aus captions.txt übernehmen → speichern. Fertig.

Reels: reel.mp4 hochladen (falls vorhanden), Trend-Audio direkt in der Instagram-App
hinzufügen — lizenzierte Musik gibt es nur dort. Stories: story.png in der App posten,
den Frage-Sticker auf die markierte Fläche legen.

Sobald die Instagram-Verbindung eingerichtet ist (Tab Social → Instagram), entfällt
das alles: Freigeben genügt, der Server veröffentlicht zur geplanten Zeit.
